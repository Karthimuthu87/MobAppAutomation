package com.example.aplikasi_absen.model

class LoginResponse : ArrayList<LoginResponseItem>()