package com.example.aplikasi_absen.model

class CheckedOutRespon: ArrayList<CheckedOut>()