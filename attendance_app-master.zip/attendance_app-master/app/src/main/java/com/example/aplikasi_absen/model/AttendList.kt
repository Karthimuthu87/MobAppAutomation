package com.example.aplikasi_absen.model


import com.google.gson.annotations.SerializedName

class AttendList : ArrayList<Attendance>()