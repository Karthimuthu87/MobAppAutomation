package com.example.aplikasi_absen.model


import com.google.gson.annotations.SerializedName

data class CountKaryawanItem(
    @SerializedName("count")
    val count: Int
)