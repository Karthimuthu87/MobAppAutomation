package com.example.aplikasi_absen.model


import com.google.gson.annotations.SerializedName

data class RegisterItem(
    @SerializedName("count")
    val count: Int
)